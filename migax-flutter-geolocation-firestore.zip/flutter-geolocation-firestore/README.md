# Geolocation Demo | 🐦 Flutter + 🔥 Firebase + 🌎 Google Maps 

Realtime Geolocation with Flutter, Firebase, and Google Maps. [Video Lesson](https://fireship.io/lessons/flutter-realtime-geolocation-firebase/).
